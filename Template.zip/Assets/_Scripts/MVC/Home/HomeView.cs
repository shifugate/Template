﻿using Project.MVC.__Base;

namespace Project.MVC.Home
{
    public class HomeView : ViewBase<HomeController, HomeModel>
    {

    }
}
