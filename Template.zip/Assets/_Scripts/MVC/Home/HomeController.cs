﻿using Project.Manager.Language.Token;
using Project.Manager.Popup;
using Project.Manager.Popup.Modal;
using Project.MVC.__Base;
using Project.Util;
using System.Collections;
using System.Threading.Tasks;
using UnityEngine;

namespace Project.MVC.Home
{
    public class HomeController : ControllerBase<HomeView, HomeModel>
    {
        private IEnumerator Start()
        {
            yield return new WaitUntil(() => Model.args != null && Model.args.Length != 0);

            SystemUtil.Log(GetType(), (string)Model.args[0]);
            SystemUtil.Log(GetType(), ((int)Model.args[1]).ToString());
        }

        public async void LoadDataAction()
        {
            PopupLoad1Modal loadModel = PopupManager.Instance.ShowModal<PopupLoad1Modal>();

            await Task.Delay(5000);

            loadModel.Hide();

            PopupManager.Instance.ShowModal<PopupMessage1Modal>()
                .Setup(LanguageManagerToken.common.error_token, 
                    "TEST TEST TEST TEST TEST TEST TEST TEST",
                    LanguageManagerToken.common.close_token,
                    () => SystemUtil.Log(GetType(), "DEBUG"));
        }
    }
}
