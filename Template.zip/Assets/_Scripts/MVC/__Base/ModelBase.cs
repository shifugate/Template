﻿using UnityEngine;

namespace Project.MVC.__Base
{
    public class ModelBase : MonoBehaviour
    {
        public object[] args;
    }
}
