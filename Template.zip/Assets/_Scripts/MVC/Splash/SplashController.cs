﻿using Project.Manager;
using Project.Manager.Language;
using Project.Manager.Language.Event;
using Project.Manager.Language.Token;
using Project.Manager.Route;
using Project.Manager.TextureContent;
using Project.MVC.__Base;
using Project.Util;
using System.Collections;
using UnityEngine;

namespace Project.MVC.Splash
{
    public class SplashController : ControllerBase<SplashView, SplashModel>
    {
        private void Awake()
        {
            AddListener();
        }

        private void OnDestroy()
        {
            RemoveListener();
        }

        private IEnumerator Start()
        {
            yield return new WaitUntil(() => InitializerManager.InitializeComplete);

            SetProperties();
            SetTexture();
        }

        private void AddListener()
        {
            LanguageManagerEvent.LanguageManagerEvent_Updated += LanguageManagerEvent_Updated;
        }

        private void RemoveListener()
        {
            LanguageManagerEvent.LanguageManagerEvent_Updated -= LanguageManagerEvent_Updated;
        }

        private void LanguageManagerEvent_Updated()
        {
            SystemUtil.Log(GetType(), $"LanguageManagerEvent_Updated: {LanguageManager.Instance.Language}");

            SetTexture();
        }

        private void SetProperties()
        {
            Model.Test0Text.text = LanguageManager.Instance.GetTranslation("splash", "message_1");
            Model.Test1Text.text = LanguageManagerToken.splash.message_2;
        }

        private void SetTexture()
        {
            if (Model.Image0RawImage.texture != null)
                Destroy(Model.Image0RawImage.texture);

            TextureContentManager.Instance.LoadTexture($"{Application.streamingAssetsPath}/Content/Texture/{LanguageManager.Instance.Language}/image0.png", 
                texture => 
                {
                    Model.Image0RawImage.texture = texture;
                });
        }

        public void PTAction()
        {
            LanguageManager.Instance.SetLanguage(LanguageManager.CountryCode.pt_BR);
        }

        public void ENAction()
        {
            LanguageManager.Instance.SetLanguage(LanguageManager.CountryCode.en_US);
        }

        public void GoHomeAction()
        {
            RouteManager.Instance.LoadScene(RouteManager.Routes.HomeScene, new object[] { "test", 0 });
        }
    }
}
