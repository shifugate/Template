﻿using Project.MVC.__Base;

namespace Project.MVC.Splash
{
    public class SplashView : ViewBase<SplashController, SplashModel>
    {

    }
}
