﻿using Project.MVC.__Base;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Project.MVC.Splash
{
    public class SplashModel : ModelBase
    {
        [SerializeField]
        private TextMeshProUGUI test0Text;
        public TextMeshProUGUI Test0Text { get { return test0Text; } }

        [SerializeField]
        private TextMeshProUGUI test1Text;
        public TextMeshProUGUI Test1Text { get { return test1Text; } }

        [SerializeField]
        private RawImage image0RawImage;
        public RawImage Image0RawImage { get { return image0RawImage; } }
    }
}
