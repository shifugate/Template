﻿using System;

namespace Project.Manager.Keyboard.Util
{
    public static class KeyboardEventUtil
    {
        public static Action EnterKeyBoard;
        public static Action HideKeyboard;
        public static Action ShowKeyboard;
    }
}
