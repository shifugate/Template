﻿using UnityEngine;

namespace Project.Manager.Keyboard.Models
{
    public class KeyboardBackground
    {
        public string type;
		public Texture2D background;
    }
}
