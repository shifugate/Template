﻿namespace Project.Manager.Keyboard.Component.Keys
{
    public class Accent
    {
        public string accent;
		public string character;
		public string result;
    }
}
