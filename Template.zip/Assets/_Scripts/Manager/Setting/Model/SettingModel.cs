﻿namespace Project.Manager.Setting.Model
{
    public class SettingModel
    {
        public bool fps_show;
        public int max_fps;
        public float timeout;
    }
}
