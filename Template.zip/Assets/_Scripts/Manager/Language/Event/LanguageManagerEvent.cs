﻿using System;

namespace Project.Manager.Language.Event
{
    public static class LanguageManagerEvent
    {
        public static Action LanguageManagerEvent_Updated;
    }
}
