﻿using System;

namespace Project.Manager.Language.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class LanguageManagerIgnoreToken : Attribute { }
}
