﻿using TMPro;
using UnityEngine;
using Project.Manager.Popup.Modal.Base;
using System;

namespace Project.Manager.Popup.Modal
{
    public class PopupLoad1Modal : PopupBaseAlphaModal
    {
        [SerializeField]
        private TextMeshProUGUI loadText;

        private bool show;
        private Action cancelCallback;

        protected override void Awake()
        {
            base.Awake();
        }

        public PopupLoad1Modal Setup(string message = null)
        {
            show = true;

            loadText.text = message != null ? message : "";

            return this;
        }

        public void CancealAction()
        {
            cancelCallback?.Invoke();

            Hide();
        }
    }
}
